from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.urls import reverse

def login_view(request):
    # If already logged in, go to dashboard
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    # Get next URL from query string
    next_url = request.GET.get('next', 'dashboard')
    print(f"Login view - next parameter: {next_url}")
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Get next from POST (preserved from hidden input)
        post_next = request.POST.get('next', 'dashboard')
        print(f"Login POST - next: {post_next}")
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome {username}!')
            print(f"Login successful, redirecting to: {post_next}")
            return redirect(post_next)
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'login.html', {'next': next_url})

def logout_view(request):
    logout(request)
    messages.info(request, 'Logged out successfully')
    return redirect('login')  # This uses the URL name 'login'

def dashboard(request):
    return render(request, 'dashboard.html')