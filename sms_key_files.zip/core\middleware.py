from django.shortcuts import redirect
from django.urls import reverse

class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        print("✅ LoginRequiredMiddleware initialized")
        
        # PUBLIC PATHS - Only these don't require login
        self.public_paths = [
            '/',
            '/dashboard/',
            '/courses/',
            '/login/',
            '/admin/',
            '/static/',
            '/media/',
        ]

    def __call__(self, request):
        current_path = request.path_info
        
        # Allow authenticated users everywhere
        if request.user.is_authenticated:
            return self.get_response(request)
        
        # Check if it's a public path
        for path in self.public_paths:
            if current_path.startswith(path):
                return self.get_response(request)
        
        # EVERYTHING ELSE redirects to core login
        return redirect(f'/login/?next={current_path}')