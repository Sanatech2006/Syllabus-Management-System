from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import redirect
from django.http import HttpResponseNotFound
from core import views as core_views

urlpatterns = [
    # Core app URLs (login, logout, dashboard)
    path('', include('core.urls')),  # This should handle root, login, logout, dashboard
    
    # Admin
    path('admin/', admin.site.urls),
    
    # Other apps
    path('dashboard/', include('modules.dashboard.urls')),
    path('courses/', include('modules.course_manage.urls')),
    path('programs/', include('modules.program_manage.urls')),
    path('uploads/', include('modules.upload_center.urls')),
    path('users/', include('modules.user_manage.urls')),
]

# Media files
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Remove the catch_all_view as it's causing issues
# The middleware will handle redirects